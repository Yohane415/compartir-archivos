<h1 align="center"> Legendary Skins -  Payday2 </h1>

<p align="center">
  <img src="https://upload.wikimedia.org/wikipedia/commons/d/d8/Payday2-logo.png">
</p>

## ⚠️Warning⚠️
**Players** can see your legendary skins equipped on your weapons!

## Instalation
Download [here!](https://github.com/8fn/LegendarySkins-PD2/archive/refs/heads/master.zip)
Extract the zip and drag the folder inside of the payday2 mods folder

Start the game and enjoy!

## Preview
![img1](https://raw.githubusercontent.com/8fn/LegendarySkins-PD2/master/docs/inventory.png)
![img2](https://raw.githubusercontent.com/8fn/LegendarySkins-PD2/master/docs/legendary_judge.png)
![img3](https://raw.githubusercontent.com/8fn/LegendarySkins-PD2/master/docs/preview.png)

## DLC Unlocker
Download [here!](https://github.com/8fn/DLC-Unlocker-PD2.git)
